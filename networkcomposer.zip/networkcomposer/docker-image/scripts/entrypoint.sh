#!/usr/bin/env bash

export HDP_VERSION=3.0.1.0-187

cd /usr/hdp/current

# Create the right symbolic links

if ! [ -L hadoop-client ]; then
  ln -s /usr/hdp/$HDP_VERSION/hadoop hadoop-client
fi

if ! [ -L hadoop-hdfs-client ]; then
  ln -s /usr/hdp/$HDP_VERSION/hadoop-hdfs hadoop-hdfs-client
fi

if ! [ -L hadoop-yarn-client ]; then
  ln -s /usr/hdp/$HDP_VERSION/hadoop-yarn hadoop-yarn-client
fi

if ! [ -L spark2-client ]; then
  ln -s /usr/hdp/$HDP_VERSION/spark2 spark2-client
fi

if ! [ -L zookeeper-client ]; then
  ln -s /usr/hdp/$HDP_VERSION/zookeeper zookeeper-client
fi

cd /etc/hadoop

if ! [ -L conf ]; then
  ln -s /usr/hdp/$HDP_VERSION/conf conf
fi

# Add the YARN server host alias into /etc/hosts
echo 10.246.161.36 cit-rdp-161-036.itcorp.aws.regeneron.com >> /etc/hosts 
