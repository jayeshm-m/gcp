#  Composer Environment

This is the source repository for GCP Cloud Composer PoC project.

1) infrastructure, contains all Terraform script code for creating Cloud Composer environment and artifacts.  
