# Enforced format on execution date

import logging
#import StringIO
import json
import airflow
from airflow import DAG
from airflow.models import Variable
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, Content
import os
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class sgNotification:
    def __init__(self,sg_key, isSuccess, emailSubject, emailBody,context):
        logger.info('Initialized SendGrid notification module')

    def __call__(self, sg_key, isSuccess, emailSubject, emailBody,context):
        # bufferedContent = StringIO.StringIO()
        try:
            logger.info("context")
            logger.info(context)
            logger.info(context['task_instance'])
            logger.info(context['task_instance'].task_id)
            a=10
            b=15
            readdict = {}
            if a < b:
                #readdict['ResponseStatus'] = 'Error'
                context['task_instance'].xcom_push(key='ResponseStatus',value='Error')          
            else:
                context['task_instance'].xcom_push(key='ResponseStatus',value='Success')          
                #readdict['ResponseStatus'] = 'Success'
            #context['task_instance'].xcom_push(key=context['task_instance'].task_id,value=readdict)
            taskinstance = context['task_instance']
            taskinstanceid = context['task_instance'].task_id
            contenttask1 = taskinstance.xcom_pull(taskinstanceid)
            logger.info(contenttask1)
            contenttask = context['task_instance'].xcom_pull(task_ids='ResponseStatus',key='ResponseStatus')
            logger.info("contenttask")
            logger.info(contenttask)
            '''if contenttask['ResponseStatus'] == 'Warning' or contenttask['ResponseStatus'] == 'Error':
                contenttask['TaskId'] = context['task_instance'].task_id
                contenttask['ExecutionDate'] = context['task_instance'].execution_date.strftime("%Y-%m-%d %H:%M:%S")
                airflowSubject = '[' + str(contenttask['ResponseStatus']) + '] CDW Airflow DAG ' + context['dag'].dag_id'''
            sg = SendGridAPIClient(sg_key)
            mail = Mail(to_email = Email("jayeshmm@virtusa.com"),
                            from_email = Email("jayesh.mahajan@regeneron.com"),
                            subject = emailSubject,
                            content = Content("text/plain", emailBody))
                            
            mail_json = mail.get()
            response = sg.client.mail.send.post(request_body=mail_json)
            #response = sg.send(message)
            if response.status_code in range(200, 204) :
                logging.info('Successfully send the notification to {0} via SendGrid'.format('recipient'))
            else:
                logging.info('Failed to send the notification to {0} via SendGrid'.format('recipient'))    
                

        except Exception as e:
            # bufferedContent.close()
            raise e
