from __future__ import print_function
import datetime

from airflow import models
from airflow.operators import bash_operator
from airflow.operators import python_operator
from airflow.contrib.operators import kubernetes_pod_operator
from airflow.contrib.kubernetes.volume_mount import VolumeMount  # noqa
from airflow.contrib.kubernetes.volume import Volume  # noqa

#from kubernetes.client import models as k8s

default_dag_args = {
    # The start_date describes when a DAG is valid / can be run. Set this to a
    # fixed point in time rather than dynamically, since it is evaluated every
    # time a DAG is parsed. See:
    # https://airflow.apache.org/faq.html#what-s-the-deal-with-start-date
    'start_date': datetime.datetime(2021, 1, 18),
}

volume_mount = VolumeMount(
    name='hdp-volume', mount_path='/usr/hdp', sub_path=None, read_only=True
)

volume_config= {
    'persistentVolumeClaim':
      {
        'claimName': 'pv-claim-hdp-binaries'
      }
    }
volume = Volume(name='hdp-volume', configs=volume_config)

# init_container_volume_mounts = [
#     k8s.V1VolumeMount(mount_path='/mnt/hdp', name='hdp-volume', sub_path=None, read_only=True)
# ]

# Define a DAG (directed acyclic graph) of tasks.
# Any task you create within the context manager is automatically added to the
# DAG object.
with models.DAG(
        'regeneron_composer_example_v4',
        schedule_interval=datetime.timedelta(days=1),
        default_args=default_dag_args) as dag:

    # The first operator demonstrate how to call a Python function defined within DAG
    # using PythonOperator.
    def greeting():
        import logging
        logging.info('Hello!')

    # An instance of an operator is called a task. In this case, the
    # hello_python task calls the "greeting" Python function.
    
    hello_python = python_operator.PythonOperator(
        task_id='hello',
        python_callable=greeting)

    # This operator demonstrate how to use Bash Operator to invoke Regeneron custom Python code
    # from native Composer environment. 
    # We upload "customer_warehouse" package into "/data" folder of Composer GCS bucket. 
    # The directory is mapped to Composer directory with "/home/airflow/gcs/data/" parent folder. 
    # Please make sure to adjust your custom system path directory set in your custome Python code. 
    # For example, the folder set with "sys.path.insert" statement for the utils. 
    cdw_user_kill = bash_operator.BashOperator(
        task_id='cdw_user_kill',
        bash_command='python /home/airflow/gcs/data/customer_warehouse/bulkload/cdw_user_kill.py /home/airflow/gcs/data/customer_warehouse/bulkload/cdw_user_kill_config.yaml'
        )

    # This Operator demonstrate how to use KubernetesPodOperator to invoke 
    # custom with HDP binaries mounted and used in the custom edge node container. 
    spark_submit_client = kubernetes_pod_operator.KubernetesPodOperator(
        # The ID specified for the task.
        task_id='spark-submit-client',

        # Name of task you want to run, used to generate Pod ID.
        name='spark-submit-client',

        # Entrypoint of the container, if not specified the Docker container's
        # entrypoint is used. The cmds parameter is templated.
        cmds=['/usr/hdp/current/spark2-client/bin/spark-submit'],
        arguments=['--keytab', '/home/spark/keytab.kt',
                   '--principal', 's.jianhe.liao@REGENERON.REGN.COM',
                   '--master', 'yarn',
                   '--deploy-mode', 'cluster',
                  '/usr/hdp/simple_job.py'],

        # The namespace to run within Kubernetes, default namespace is
        # `default`. There is the potential for the resource starvation of
        # Airflow workers and scheduler within the Cloud Composer environment,
        # the recommended solution is to increase the amount of nodes in order
        # to satisfy the computing requirements. Alternatively, launching pods
        # into a custom namespace will stop fighting over resources.
        namespace='default',

        # Docker image specified. Defaults to hub.docker.com, but any fully
        # qualified URLs will point to a custom repository. Supports private
        # gcr.io images if the Composer Environment is under the same
        # project-id as the gcr.io images and the service account that Composer
        # uses has permission to access the Google Container Registry
        # (the default service account has permission)
        image='us.gcr.io/gna-dps-nprd/regn-comp-k8s:latest',

        # Image pull policy 'Always' or 'IfNotPresent'. Set the 'Always' for testing
        image_pull_policy='Always', 

        # List of VolumeMount objects to pass to the pod.
        volume_mounts=[volume_mount],

        # List of Volume objects to pass to the Pod.
        volumes=[volume],
 
        # Resources
        resources={
          'request_memory':'500Mi',
          'request_cpu':'300m',
          'limit_memory':'1.5Gi',
          'limit_cpu':'900m'
        },

        # affinity allows you to constrain which nodes your pod is eligible to
        # be scheduled on, based on labels on the node. In this case, if the
        # label 'cloud.google.com/gke-nodepool' with value
        # 'nodepool-label-value' or 'nodepool-label-value2' is not found on any
        # nodes, it will fail to schedule.
        affinity={
            'nodeAffinity': {
                # requiredDuringSchedulingIgnoredDuringExecution means in order
                # for a pod to be scheduled on a node, the node must have the
                # specified labels. However, if labels on a node change at
                # runtime such that the affinity rules on a pod are no longer
                # met, the pod will still continue to run on the node.
                'requiredDuringSchedulingIgnoredDuringExecution': {
                    'nodeSelectorTerms': [{
                        'matchExpressions': [{
                            # When nodepools are created in Google Kubernetes
                            # Engine, the nodes inside of that nodepool are
                            # automatically assigned the label
                            # 'cloud.google.com/gke-nodepool' with the value of
                            # the nodepool's name.
                            'key': 'cloud.google.com/gke-nodepool',
                            'operator': 'In',
                            # The label key's value that pods can be scheduled
                            # on.
                            'values': [
                                'regn-composer-dev-k8s-pool'
                            ]
                        }]
                    }]
                }
            }
        }
        )
        
    # This operator run the same Python command as "cdw_user_kill" operator above. However, it invokes the command
    # in the Kubernetes container instead of from Composer native environment. 
    # Please note that "customer_warehouse" is mounted to container under "/usr/hdp" directory. 
    # So we need to adjust the directory in our Python command as well the custom Python files accordingly. 
    pod_cdw_user_kill = kubernetes_pod_operator.KubernetesPodOperator(
        # The ID specified for the task.
        task_id='pod-cdw-user-kill',

        # Name of task you want to run, used to generate Pod ID.
        name='pod-cdw-user-kill',

        cmds=['python'],

	arguments=['/usr/hdp/customer_warehouse/bulkload/cdw_user_kill.py',
                   '/usr/hdp/customer_warehouse/bulkload/cdw_user_kill_config.yaml'],

        namespace='default',
        image='us.gcr.io/gna-dps-nprd/regn-comp-k8s:latest',

        image_pull_policy='Always',

        # List of VolumeMount objects to pass to the pod.
        volume_mounts=[volume_mount],

        # List of Volume objects to pass to the Pod.
        volumes=[volume],
        
        # Resources
        resources={
          'request_memory':'500Mi', 
          'request_cpu':'300m', 
          'limit_memory':'1.5Gi', 
          'limit_cpu':'900m'
        },

        # affinity allows you to constrain which nodes your pod is eligible to
        affinity={
            'nodeAffinity': {
                'requiredDuringSchedulingIgnoredDuringExecution': {
                    'nodeSelectorTerms': [{
                        'matchExpressions': [{
                            'key': 'cloud.google.com/gke-nodepool',
                            'operator': 'In',
                            'values': [
                                'regn-composer-dev-k8s-pool'
                            ]
                        }]
                    }]
                }
            }
        }
        )

    # Define the order in which the tasks complete by using the >> and <<
    # operators. In this example, hello_python executes before goodbye_bash.
    hello_python >> cdw_user_kill >> spark_submit_client >> pod_cdw_user_kill
