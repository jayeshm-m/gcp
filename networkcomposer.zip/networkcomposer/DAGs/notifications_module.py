#!/usr/bin/python
import boto3 # For AWS SDK
import os
import configparser
import traceback # For detailed error logging
import os  # For running cmd
import sys  # For exiting code
import yaml  # To read YAML config file
import logging  # For python logger
import json  # To parse JSON tags to S3
#from airflow.models import Variable
import datetime

from send_grid import sgNotification

from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email
from python_http_client.exceptions import HTTPError

config = configparser.RawConfigParser(allow_no_value=True)
config.readfp(open('/home/airflow/gcs/dags/config.ini'))  # cloud shell path 
os.environ["NLS_LANG"] = "AMERICAN_AMERICA.UTF8"
apiStr =  config.get('API_KEY','SENDGRID_API_KEY')
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



def get_sendgrid_key():
    try:
        '''envName=Variable.get('ENV')
        return Variable.get(envName +"-" + variableName)'''
        return apiStr
    except Exception as e:  
        return("")



#This section of the code is called when the DAG results in a Failiure
def sg_notify_fail(context):
    stepName = context["task"].task_id
    dag_id = context["dag"].dag_id
    logging.info("sg_notify_fail")
    logging.info(stepName)
    logging.info(dag_id)
    project=dag_id.split("_")[0]
    today=datetime.datetime.now().strftime ("%m/%d/%Y")

    emailSub ="Processing Error: Processing process " + dag_id + " failed on " + today
    emailBod ="Processing process failed on the  " + stepName
    emailBod += '\n\nPlease open an incident ticket in Service Now and assign to Platform Services Team.'

    
    sg_obj = sgNotification(sg_key=get_sendgrid_key(),isSuccess="false",emailSubject=emailSub,emailBody=emailBod,context=context)
    sg_obj(sg_key=get_sendgrid_key(),isSuccess="false",emailSubject=emailSub,emailBody=emailBod,context=context)

#This section of the code is called when the DAG results in a Success
def sg_notify_success(context):    
    
    stepName = context["task"].task_id
    dag_id = context["dag"].dag_id

    arnVariableName= "PLATFORM-SERVICES" 

    emailSub ="Processing Success: Processing process " + dag_id 

    emailBod = "Processing process "  + dag_id + " has been completed succesfully."

    sg_obj = sgNotification(sg_key=get_sendgrid_key(),isSuccess="false",emailSubject=emailSub,emailBody=emailBod,context=context)
    sg_obj(sg_key=get_sendgrid_key(),isSuccess="true",emailSubject=emailSub,emailBody=emailBod,context=context)
'''
def sg_notify_alert(context):
    
    stepName = context["task"].task_id.replace('_',' ')
    dag_id = context["dag"].dag_id

    arnVariableName= "arn:aws:sns:us-east-1:486047195917##"
    today=datetime.datetime.now().strftime ("%m/%d/%Y")

    emailSub ="Ingestion Data file missing - << Step_name >>" 
    emailBod ="<p>Ingestion process didn't find any source files for the below <step_name> for given timeline." 
    emailBod += '\nPlease reach out to the vendor to address this issue.'
    emailBod += '\nFor additional information, please contact Commercial System Support <commercialsystemsupport@xyz.com> </p>'
    sg_obj = sgNotification(sg_key=get_sendgrid_key(),isSuccess="false",emailSubject=emailSub,emailBody=emailBod,context=context)
    sg_obj(sg_key=get_sendgrid_key(),isSuccess="false",emailSubject=emailSub,emailBody=emailBod,context=context)'''
    


